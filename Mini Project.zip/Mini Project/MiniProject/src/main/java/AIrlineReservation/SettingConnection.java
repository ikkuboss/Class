package AIrlineReservation;

import java.sql.Connection;
import java.sql.DriverManager;

public class SettingConnection 
{

	public static void main(String[] args)
	{
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/myfirstdb";
		String un="root";
		String pass="root";
		
		try
		{
			Class.forName(driver);
			
			Connection conn=DriverManager.getConnection(url,un,pass);
			if(conn!=null)
			{
				System.out.println("Connected");
			}
			else
			{
				System.out.println("not Conected");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
