package AIrlineReservation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

class Inputs
{

	String driver="com.mysql.cj.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/airlinereservation";
	String un="root";
	String pass="root";
	
	Connection conn=null;
	Statement st=null;
	ResultSet rs=null;
	
	Scanner sc = new Scanner(System.in);
	void Destination()
	{	
		try
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,pass);
			
			st=conn.createStatement();
			
			String s="select * from destination";
			rs=st.executeQuery(s);
			System.out.println("********DESTINATION********");
			System.out.println("***************************");
			System.out.println("***   id"+"\t"+"name    ***");
			while(rs.next())
			{
				System.out.println("***   "+rs.getString(1)+"\t       "+rs.getString(2)+"\t***");
				
			}
			System.out.println("***************************");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	void booking()
	{	
		try
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,pass);
			
			st=conn.createStatement();
			
			String s="select * from destination";
			rs=st.executeQuery(s);
			System.out.println("********DESTINATION********");
			System.out.println("***************************");
			System.out.println("***   id"+"\t"+"name    ***");
			while(rs.next())
			{
				System.out.println("***   "+rs.getString(1)+"\t       "+rs.getString(2)+"\t***");
				
			}
			System.out.println("***************************");
			
			int loc;
			int des;
			String name,mail;
			long mobile;
			int age;
		
			System.out.print("Enter your name =");
			name=sc.nextLine();
			System.out.print("Enter your Email =");
			mail=sc.nextLine();
			
			System.out.print("Enter your mobile number =");
			mobile=sc.nextLong();
			
				System.out.print("Enter your age =");
				age=sc.nextInt();
				
				
				System.out.print("Select the location [number] = ");
				loc=sc.nextInt();
				System.out.print("Select the destination [number] = ");
				des=sc.nextInt();
				
				System.out.println("Your name is ="+name);
				System.out.println("Your Email is ="+mail);
				System.out.println("Your mobile number is ="+mobile);
				System.out.println("Age of the passenger is ="+age);
				
				if(loc==des)
				{
					System.out.println("Location and Destination is same");
				}
				else
				{
					String s2="select * from destination where desid="+loc;
					rs=st.executeQuery(s2);
		
					if(rs.next())
					{
						System.out.println("Your selected location is ="+rs.getString(2));
					}
			
					String s3="select * from destination where desid="+des;
					rs=st.executeQuery(s3);
				
					if(rs.next())
					{
						System.out.println("Your selected Destination is ="+rs.getString(2));
					}
				
					
					
					int a=1000;
					int b;
					if(loc==1 && des==2)
					{
						b=a+1500;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==1 && des==3)
					{
						b=a+2400;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==1 && des==4)
					{
						b=a+1200;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==2 && des==1)
					{
						b=a+800;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==2 && des==3)
					{
						b=a+1800;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==2 && des==4)
					{
						b=a+2300;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==3 && des==1)
					{
						b=a+2100;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==3 && des==2)
					{
						b=a+2200;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==3 && des==4)
					{
						b=a+1900;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==4 && des==1)
					{
						b=a+2500;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==4 && des==2)
					{
						b=a+1700;
						System.out.println("Your fare is ="+b);
					}
					else if(loc==4 && des==3)
					{
						b=a+1900;
						System.out.println("Your fare is ="+b);
					}	
				}
			
				int rs=st.executeUpdate("insert into details values('"+name+"','"+mail+"',"+mobile+","+age+","+des+")");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	void view()
	{
		try
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,pass);
			
			st=conn.createStatement();
			String name;
			
			System.out.println("Enter the name for Search =");
			name=sc.nextLine();
			
			String s4="select * from details where pname='"+name+"'";
			rs=st.executeQuery(s4);
			
			if(rs.next())
			{
				String s5="select p.pname,p.pemail,pmobile,age,d.desti from details p inner join destination d on p.desid=d.desid;";
				rs=st.executeQuery(s5);
				if(rs.next())
				{
					System.out.println("Passenger name is ="+rs.getString(1)+"\n"+"Passenger's Email is ="+rs.getString(2)+"\n"+"Passenger's Mobile number is ="+rs.getString(3)+"\n"+"Age of the Passenger is ="+rs.getString(4)+"\n"+"Passengers selected destination is ="+rs.getString(5));
				}
			}
			else
			{
				System.out.println("Passenger dosen't exist with this name :");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

public class Main
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Inputs iobj=new Inputs();
			
		while(true) 
		{
			System.out.println("*********MENU*********");
			System.out.println("**********************");
			System.out.println("**   1.DESTINATION  **");
			System.out.println("**   2.BOOKING      **");
			System.out.println("**   3.VIEW         **");
			System.out.println("**   4.EXIT         **");
			System.out.println("**********************");
			
			int ch;
			
			System.out.print("Enter your choice =");
			ch=sc.nextInt();

			switch(ch)
			{
				case 1:
					iobj.Destination();
					System.out.println();
					break;
				case 2:
					iobj.booking();
					System.out.println();
					break;			
				case 3:
					iobj.view();
					System.out.println();
					break;
				case 4:
					System.out.println("Thnak you for visit :");
					System.exit(0);
					break;
				default:
					System.out.println("Invalid input");
					System.out.println();
					break;
			}
			
		}
	}
}

