package AIrlineReservation;

public class Admin {

	public static void main(String[] args) 
	{	

	}

}
