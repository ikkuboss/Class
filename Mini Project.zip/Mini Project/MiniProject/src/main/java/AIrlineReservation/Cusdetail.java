package AIrlineReservation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Cusdetail 
{
	public static void main(String[] args) 
	{
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/myfirstdb";
		String un="root";
		String pass="root";
		
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;	
		
		try
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,un,pass);
			
			st=conn.createStatement();
			String s="select * from student";
			
			rs=st.executeQuery(s);
			
			System.out.println("id"+"\t"+"name"+" \t\t"+"mail"+"\t\t\t\t"+"age");
			while(rs.next())
			{
				
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+"\t"+rs.getString(3)+"\t\t"+rs.getString(4));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
